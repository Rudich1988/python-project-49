### Hexlet tests and linter status:
[![Actions Status](https://github.com/Rudich1988/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Rudich1988/python-project-49/actions)