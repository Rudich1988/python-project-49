#!/usr/bin/env python3
from brain_games.games.brain_progression_logic import brain_progression_logic


def progression():
    print(brain_progression_logic())


if __name__ == '__main__':
    progression()
